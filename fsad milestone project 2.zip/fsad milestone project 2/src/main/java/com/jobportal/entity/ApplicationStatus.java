package com.jobportal.entity;

public enum ApplicationStatus {
    APPLIED,
    SHORTLISTED,
    REJECTED
}
